#include <iostream>
#include <graphics.h>
#include <conio.h>
#include <stdlib.h>

using namespace std;

void nationalFlag();
void miniHouse();
void dda();
void earth();
void midPointCircle();
void rocket();
void emoji();
void threeDBox();
void humanBaby();
void animateBoat();

int main()
{
    int choice;
    int gd = DETECT, gm;

    initgraph(&gd, &gm, "");
    initwindow(1024, 1024, "Main");

    while (1)
    {
        system("cls"); // Clear the screen
        cout << "Mohammad Jewel Hosen (Abrar)\nID: CSE2001019038\n\n";
        cout << "Graphics Programs Menu:\n";
        cout << "1. National Flag\n";
        cout << "2. Mini House\n";
        cout << "3. DDA Line Drawing\n";
        cout << "4. Earth\n";
        cout << "5. Mid Point Circle\n";
        cout << "6. Rocket\n";
        cout << "7. Emoji\n";
        cout << "8. 3D Box\n";
        cout << "9. Human Baby\n";
        cout << "10. Moving Boat\n";
        cout << "0. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            nationalFlag();
            break;
        case 2:
            miniHouse();
            break;
        case 3:
            dda();
            break;
        case 4:
            earth();
            break;
        case 5:
            midPointCircle();
            break;
        case 6:
            rocket();
            break;
        case 7:
            emoji();
            break;
        case 8:
            threeDBox();
            break;
        case 9:
            humanBaby();
            break;
        case 10:
            animateBoat();
            break;
        case 0:
            closegraph();
            exit(0);
        default:
            cout << "Invalid choice, please try again.\n";
            delay(1000);
        }
    }

    return 0;
}

void nationalFlag()
{
    cleardevice();
    initwindow(1024, 1024, "National Flag");

    setcolor(GREEN);
    rectangle(261, 180, 540, 350);
    setfillstyle(SOLID_FILL, GREEN);
    floodfill(265, 190, GREEN);

    setcolor(YELLOW);
    rectangle(245, 155, 260, 625);
    setfillstyle(SOLID_FILL, YELLOW);
    floodfill(247, 158, YELLOW);

    setcolor(RED);
    circle(400, 265, 60);
    setfillstyle(SOLID_FILL, RED);
    floodfill(401, 265, RED);

    getch();

}

void miniHouse()
{
    cleardevice();
    initwindow(1024, 1024, "Mini House");

    setcolor(WHITE);       // Hut
    line(300,200,750,200);
    line(750,200,750,190);
    line(750,190,300,190);
    line(300,190,300,200);
    setfillstyle(1,YELLOW);
    floodfill(305,195,WHITE);
    line(300,200,279,182);
    line(279,182,300,190);
    setfillstyle(1,YELLOW);
    floodfill(299,195,WHITE);
    line(750,200,771,182);
    line(771,182,750,190);
    setfillstyle(1,YELLOW);
    floodfill(751,195,WHITE);

    line(310,201,201,330);
    line(201,330,215,330);
    line(215,330,324,201);
    line(324,201,310,201);
    setfillstyle(1,LIGHTBLUE);
    floodfill(312,204,WHITE);

    line(325,201,431,330);
    line(431,330,840,330);
    line(840,330,740,201);
    setfillstyle(1,LIGHTBLUE);
    floodfill(330,204,WHITE);

    line(215,330,215,500);
    line(215,500,450,519);
    line(450,519,450,330);
    setfillstyle(1,LIGHTMAGENTA);
    floodfill(220,400,WHITE);

    line(450,519,820,495);
    line(820,495,820,330);
    setfillstyle(1,LIGHTMAGENTA);
    floodfill(455,515,WHITE);

    setcolor(WHITE);
    line(280,345,380,350);
    line(380,350,380,449);
    line(380,449,280,440);
    line(280,440,280,345);
    setfillstyle(1,LIGHTGREEN);
    floodfill(285,350,WHITE);

    line(600,365,685,363);
    line(600,365,600,509);
    line(600,509,685,504);
    line(685,504,685,363);
    setfillstyle(1,LIGHTGREEN);
    floodfill(610,370,WHITE);

    setcolor(WHITE);
    line(215,500,195,499);
    line(195,499,193,520);
    line(193,520,450,540);
    line(450,540,843,514);
    line(843,514,840,494);
    line(820,495,840,494);
    setfillstyle(1,BROWN);
    floodfill(839,495,WHITE);

    getch();

}

void dda()
{
    float x1, y1, x2, y2;
    cleardevice();
    initwindow(1024, 1024, "DDA Line Drawing");

    cout << "Enter the value of x1 and y1: ";
    cin >> x1 >> y1;

    cout << "Enter the value of x2 and y2: ";
    cin >> x2 >> y2;

    float dx, dy, step, x, y;
    int i;

    dx = abs(x2 - x1);
    dy = abs(y1 - y2);

    if (dx > dy)
        step = dx;
    else
        step = dy;

    dx = dx / step;
    dy = dy / step;

    x = x1;
    y = y1;
    i = 1;

    while (i <= step)
    {
        putpixel(x, y, WHITE);
        x = x + dx;
        y = y + dy;
        i = i + 1;
        delay(100);
    }

    getch();

}

void earth()
{
    cleardevice();
    initwindow(1024, 1024, "Earth");

    setcolor(WHITE);              //    earth body shape
    circle(490,310,160);
    setfillstyle(1,LIGHTBLUE);
    floodfill(490,300,WHITE);

    setcolor(GREEN);              // green shape
    ellipse(520,200,280,280,15,9);
    setfillstyle(1,GREEN);
    floodfill(520,200,GREEN);

    ellipse(540,185,280,280,7,5);
    setfillstyle(1,GREEN);
    floodfill(540,185,GREEN);

    ellipse(420,220,280,280,30,17);
    setfillstyle(1,GREEN);
    floodfill(420,225,GREEN);
    circle(445,205,17);
    ellipse(400,260,280,280,30,50);
    setfillstyle(1,GREEN);
    floodfill(445,205,GREEN);
    floodfill(400,261,GREEN);
    ellipse(372,320,280,280,40,60);
    floodfill(372,320,GREEN);
    circle(370,260,25);
    setfillstyle(1,GREEN);
    floodfill(367,260,GREEN);

    ellipse(450,415,280,280,60,40);
    setfillstyle(1,GREEN);
    floodfill(450,415,GREEN);
    ellipse(510,430,280,280,50,30);
    setfillstyle(1,GREEN);
    floodfill(515,430,GREEN);

    ellipse(540,380,280,280,10,5);
    setfillstyle(1,GREEN);
    floodfill(540,380,GREEN);

    ellipse(616,320,280,280,30,60);
    setfillstyle(1,GREEN);
    floodfill(616,320,GREEN);
    circle(580,300,20);
    setfillstyle(1,GREEN);
    floodfill(580,300,GREEN);
    circle(600,260,38);
    setfillstyle(1,GREEN);
    floodfill(600,260,GREEN);
    circle(630,280,15);
    setfillstyle(1,GREEN);
    floodfill(630,280,GREEN);
    floodfill(639,280,GREEN);
    ellipse(600,370,280,280,30,30);
    setfillstyle(1,GREEN);
    floodfill(590,370,GREEN);

    setcolor(BLACK);               // eyes
    circle(430,270,23);
    setfillstyle(1,BLACK);
    floodfill(430,270,BLACK);
    circle(550,270,23);
    setfillstyle(1,BLACK);
    floodfill(550,270,BLACK);
    setcolor(WHITE);
    circle(437,265,10);
    circle(422,277,5);
    circle(543,265,10);
    circle(558,277,5);
    setfillstyle(1,WHITE);
    floodfill(437,265,WHITE);
    floodfill(422,277,WHITE);
    floodfill(543,265,WHITE);
    floodfill(558,277,WHITE);

    setcolor(RED);
    ellipse(400,320,280,280,21,10);
    ellipse(580,320,280,280,21,10);
    setfillstyle(1,LIGHTRED);
    floodfill(400,320,RED);
    floodfill(580,320,RED);

    setcolor(BLACK);                    // lip
    ellipse(490,350,180,360,30,25);
    ellipse(490,345,192,349,27,25);
    line(460,349,464,349);
    line(516,349,519,349);
    setfillstyle(1,BLACK);
    floodfill(462,351,BLACK);
    getch();

}

void plotpoints(int xc, int yc, int x, int y)
{
    putpixel(xc + x, yc + y, WHITE);
    putpixel(xc - x, yc + y, WHITE);
    putpixel(xc + x, yc - y, WHITE);
    putpixel(xc - x, yc - y, WHITE);
    putpixel(xc + y, yc + x, WHITE);
    putpixel(xc - y, yc + x, WHITE);
    putpixel(xc + y, yc - x, WHITE);
    putpixel(xc - y, yc - x, WHITE);

    delay(100);
}

void drawcircle(int xc, int yc, int r)
{
    int x = 0, y = r;
    int d = 1 - r;

    plotpoints(xc, yc, x, y);

    while (x < y)
    {
        x++;
        if (d < 0)
        {
            d += 2 * x + 1;
        }
        else
        {
            y--;
            d += 2 * (x - y) + 1;
        }
        plotpoints(xc, yc, x, y);
    }
}

void midPointCircle()
{
    int xc, yc, r;

    cleardevice();
    initwindow(1024, 1024, "Mid Point Circle");

    cout << "Enter the Center of The Circle (xc, yc): ";
    cin >> xc >> yc;

    cout << "Enter The Radius of The Circle (r): ";
    cin >> r;

    drawcircle(xc, yc, r);

    getch();

}


void rocket()
{
    cleardevice();
    initwindow(1024, 1024, "Rocket");

    setcolor(RED);           // rocket
    line(450,70,380,152);
    line(450,70,520,152);
    ellipse(450,160,390,150,80,25);
    setfillstyle(1,RED);
    floodfill(450,80,RED);

    ellipse(410,270,125,230,50,150);
    ellipse(490,270,310,55,50,150);
    line(377,382,523,382);
    setfillstyle(1,YELLOW);
    floodfill(450,142,RED);

    setcolor(BLACK);
    circle(390,370,6);
    circle(412,370,6);
    circle(510,370,6);
    circle(488,370,6);
    setfillstyle(1,LIGHTGRAY);
    floodfill(390,370,BLACK);
    floodfill(412,370,BLACK);
    floodfill(510,370,BLACK);
    floodfill(488,370,BLACK);

    setcolor(WHITE);
    line(400,436,500,436);
    line(400,436,340,660);
    line(500,436,570,660);
    line(340,660,570,660);
    setfillstyle(1,WHITE);
    floodfill(410,440,WHITE);


    setcolor(WHITE);
    ellipse(370,560,280,280,70,30);
    ellipse(400,510,280,280,50,40);
    ellipse(570,558,280,280,70,30);
    ellipse(540,510,280,280,50,40);
    ellipse(310,620,280,280,70,50);
    ellipse(630,620,280,280,80,60);
    setfillstyle(1,WHITE);
    floodfill(370,560,WHITE);
    floodfill(400,510,WHITE);
    floodfill(570,558,WHITE);
    floodfill(540,510,WHITE);
    floodfill(310,620,WHITE);
    floodfill(630,620,WHITE);
    floodfill(550,540,WHITE);
    floodfill(590,580,WHITE);
    floodfill(550,590,WHITE);
    floodfill(330,580,WHITE);
    floodfill(330,550,WHITE);
    floodfill(380,480,WHITE);
    floodfill(370,535,WHITE);


    setcolor(RED);
    ellipse(380,390,290,372,20,40);
    ellipse(520,390,167,250,20,40);
    line(385,425,515,425);
    setfillstyle(1,LIGHTGREEN);
    floodfill(400,400,RED);
    line(385,425,385,435);
    line(385,435,515,435);
    line(515,435,515,425);
    setfillstyle(1,LIGHTGRAY);
    floodfill(390,430,RED);

    setcolor(RED);
    line(450,300,425,330);
    line(450,300,475,330);
    line(425,330,450,460);
    line(475,330,450,460);
    setfillstyle(1,RED);
    floodfill(450,330,RED);
    floodfill(450,410,RED);
    floodfill(450,430,RED);
    floodfill(450,455,RED);

    setcolor(RED);
    line(360,300,310,380);
    line(310,380,360,460);
    line(360,460,350,390);
    line(350,390,370,360);
    line(370,360,360,300);

    line(540,300,590,380);
    line(590,380,540,460);
    line(540,460,550,390);
    line(550,390,530,360);
    line(530,360,540,300);
    setfillstyle(1,RED);
    floodfill(360,305,RED);
    floodfill(540,305,RED);

    setcolor(BLACK);
    circle(450,210,40);
    setfillstyle(1,LIGHTRED);
    floodfill(450,210,BLACK);
    circle(450,210,30);
    setfillstyle(1,LIGHTBLUE);
    floodfill(450,210,BLACK);

    getch();

}

void emoji()
{
    cleardevice();
    initwindow(1024, 1024, "Emoji");

    setcolor(WHITE);    // Emoji
    circle(400,310,145);
    setfillstyle(1,YELLOW);
    floodfill(400,300,WHITE);

    setcolor(BLACK);
    circle(350,260,30);
    setfillstyle(1,WHITE);
    floodfill(351,261,BLACK);

    setcolor(BLACK);
    circle(450,260,30);
    setfillstyle(1,WHITE);
    floodfill(451,261,BLACK);

    setcolor(BLACK);
    circle(350,260,15);
    setfillstyle(1,BLACK);
    floodfill(351,261,BLACK);

    setcolor(BLACK);
    circle(450,260,15);
    setfillstyle(1,BLACK);
    floodfill(451,261,BLACK);



    setcolor(BLUE);
    line(400,310,420,330);
    line(400,310,380,330);
    line(380,330,420,330);
    setfillstyle(1,BLUE);
    floodfill(400,315,BLUE);

    setcolor(BLACK);
    line(345,350,455,350);
    ellipse(400,350,180,360,55,50);
    setfillstyle(6,RED);
    floodfill(346,351,BLACK);

    getch();

}

void threeDBox()
{
    cleardevice();
    initwindow(1024, 1024, "3D Box");

    setcolor(MAGENTA);
    line(280,180,380,250);
    line(380,250,500,220);
    line(500,220,400,150);
    line(400,150,280,180);
    setfillstyle(1,MAGENTA);
    floodfill(290,180,MAGENTA);

    setcolor(GREEN);
    line(278,185,375,255);
    line(278,185,264,287);
    line(264,287,361,357);
    line(361,357,375,255);
    setfillstyle(1,GREEN);
    floodfill(280,200,GREEN);

    setcolor(LIGHTBLUE);
    line(383,255,502,225);
    line(383,255,369,359);
    line(369,359,488,327);
    line(488,327,502,225);
    setfillstyle(1,LIGHTBLUE);
    floodfill(390,260,LIGHTBLUE);

    setcolor(WHITE);
    line(278,185,280,180);
    line(280,180,380,250);
    line(278,185,375,255);
    line(500,220,502,225);
    line(369,359,361,357);
    line(380,250,500,220);
    line(383,255,502,225);
    line(383,255,369,359);
    line(361,357,375,255);
    setfillstyle(1,YELLOW);
    floodfill(367,351,WHITE);

    getch();

}

void humanBaby()
{
    cleardevice();
    initwindow(1024, 1024, "Human Baby");

    setcolor(WHITE);
    setfillstyle(1,WHITE);
    floodfill(5,5,WHITE);

    setcolor(BROWN);
    ellipse(340,200,310,200,120,120);
    ellipse(330,260,280,280,110,60);
    setfillstyle(1,BROWN);
    floodfill(340,200,BROWN);
    floodfill(330,260,BROWN);

    setcolor(BROWN);
    ellipse(460,230,290,160,20,23);
    ellipse(453,240,210,338,16,20);
    line(443,220,440,255);
    setfillstyle(1,BROWN);
    floodfill(460,230,BROWN);

    setcolor(BLACK);
    ellipse(465,230,340,140,10,15);
    ellipse(460,241,425,220,10,15);
    circle(456,249,4);
    setfillstyle(1,BLACK);
    floodfill(456,249,BLACK);

    setcolor(WHITE);
    circle(270,220,23);
    circle(360,220,23);
    setfillstyle(1,WHITE);
    floodfill(270,220,WHITE);
    floodfill(360,220,WHITE);

    setcolor(BLACK);
    circle(270,220,20);
    circle(360,220,20);
    setfillstyle(1,BLACK);
    floodfill(270,220,BLACK);
    floodfill(360,220,BLACK);

    setcolor(WHITE);
    circle(275,213,7);
    circle(365,213,7);
    setfillstyle(1,WHITE);
    floodfill(275,213,WHITE);
    floodfill(365,213,WHITE);

    setcolor(LIGHTRED);
    ellipse(253,260,280,280,12,7);
    ellipse(387,260,280,280,12,7);
    setfillstyle(1,LIGHTRED);
    floodfill(253,260,LIGHTRED);
    floodfill(387,260,LIGHTRED);

    setcolor(BLACK);
    ellipse(310,270,180,360,20,10);
    ellipse(310,250,360,180,6,5);

    setcolor(BLACK);
    ellipse(330,260,160,330,110,60);
    line(300,317,274,330);
    line(274,330,245,435);
    line(245,435,265,437);
    line(265,437,310,380);
    line(313,360,310,380);
    line(310,380,318,410);
    line(318,410,330,418);
    line(330,418,350,430);
    line(350,430,370,430);
    line(370,430,360,400);
    line(360,400,363,360);
    line(370,430,380,450);
    line(380,450,396,450);
    line(396,450,408,410);
    line(408,410,405,360);
    line(402,424,420,418);
    line(420,418,430,404);
    line(430,404,437,360);
    line(437,360,420,335);
    line(420,335,398,320);
    line(398,320,370,315);
    setfillstyle(1,BROWN);
    floodfill(305,320,BLACK);

    setcolor(BROWN);
    ellipse(430,370,255,480,47,48);
    setfillstyle(1,BLUE);
    floodfill(445,370,BROWN);
    ellipse(470,400,280,280,23,33);
    setfillstyle(1,BROWN);
    floodfill(470,400,BROWN);
    floodfill(460,380,BROWN);
    ellipse(485,420,280,280,30,15);
    setfillstyle(1,BROWN);
    floodfill(490,420,BROWN);
    ellipse(510,425,280,280,10,20);
    setfillstyle(1,BROWN);
    floodfill(510,430,BROWN);

    ellipse(250,442,280,280,20,10);
    ellipse(390,460,280,280,20,10);
    setfillstyle(1,BROWN);
    floodfill(250,442,BROWN);
    floodfill(390,460,BROWN);

    getch();

}

void animateBoat()
{
    cleardevice();
    initwindow(1200, 800, "Boat");

    setcolor(WHITE);
    // Ground Line
    line(10, 500, 1000, 500);

    for (int i = 0; i <= 1000; i = i + 1)
    {

        // Street Line
        line(10, 500, 1000, 500);

        // Boat Design
        line(100 + i, 480, 300 + i, 480);
        line(100 + i, 480, 50 + i, 400);
        line(300 + i, 480, 350 + i, 400);
        line(50 + i, 400, 350 + i, 400);

        setfillstyle(SOLID_FILL, RED);
        floodfill(110 + i, 470, WHITE);

        // Boat Hull
        line(150 + i, 400, 150 + i, 350);
        line(250 + i, 400, 250 + i, 350);
        line(150 + i, 350, 250 + i, 350);
        setfillstyle(SOLID_FILL, GREEN);
        floodfill(155 + i, 390, WHITE);

        delay(20);
        cleardevice();
    }

    getch();

}

